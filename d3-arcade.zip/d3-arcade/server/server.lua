ESX = exports['es_extended']:GetSharedObject()

local supercomputer = {
    isInGamingHouse = false,
    computerType = Config.SuperMachine,
    computerGPU = Config.GPUList[1],
    computerCPU = Config.CPUList[1],
}
local retrocomputer = {
    isInGamingHouse = false,
    computerType = Config.RetroMachine,
    computerGPU = Config.GPUList[2],
    computerCPU = Config.CPUList[2],
}

--[[
QBCore.Commands.Add('testgames', 'Opens an arcade supercomputer for testing purposes', {}, false, function(source)
    local src = source
    TriggerClientEvent('d3-arcade:check:ticket', src, supercomputer)
end, 'admin')
]]--

RegisterNetEvent('d3-arcade:singleUse', function()
    local src = source
    --local Player = QBCore.Functions.GetPlayer(source)
    local xPlayer = ESX.GetPlayerFromId(_source)
	local price = Config.singleUsePrice
    if not Config.enableGameHouse or xPlayer.removeMoney("cash", price, "arcade") then
        TriggerClientEvent('d3-arcade:check:ticket', src, retrocomputer)
    else
        TriggerClientEvent("d3-arcade:nomoney", source);
    end
end)

RegisterNetEvent("d3-arcade:buyTicket")
AddEventHandler("d3-arcade:buyTicket", function(ticket)
    local data = Config.ticketPrice[ticket]
    local xPlayer = ESX.GetPlayerFromId(_source)
    if xPlayer.removeMoney("cash", data.price, "arcade") then
        TriggerClientEvent("d3-arcade:ticketResult", source, ticket);
    else
        TriggerClientEvent("d3-arcade:nomoney", source);
    end
end)